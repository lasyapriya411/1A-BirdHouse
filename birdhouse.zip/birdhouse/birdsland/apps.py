from django.apps import AppConfig


class BirdslandConfig(AppConfig):
    name = 'birdsland'
